self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "da5b686621e02d171eaf35c6c83e8648",
    "url": "./index.html"
  },
  {
    "revision": "de7d41d331ea226c374b",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "ee72b060a5178176c8cb",
    "url": "./static/css/main.cd15ab81.chunk.css"
  },
  {
    "revision": "de7d41d331ea226c374b",
    "url": "./static/js/2.e91b01a3.chunk.js"
  },
  {
    "revision": "21eac3191d7158f787afabb4233ee5b8",
    "url": "./static/js/2.e91b01a3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ee72b060a5178176c8cb",
    "url": "./static/js/main.318124fd.chunk.js"
  },
  {
    "revision": "89f12898a872a6affcf1",
    "url": "./static/js/runtime-main.615dcbd1.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "4393be32df4cde10e2ddf3fe71704e9a",
    "url": "./static/media/imgLoader.4393be32.svg"
  }
]);