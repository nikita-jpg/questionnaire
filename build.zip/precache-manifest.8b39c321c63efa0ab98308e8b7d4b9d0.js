self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "39d462b10dcb68f7f7089b5ecea5f8f8",
    "url": "./index.html"
  },
  {
    "revision": "eab8c368954ed29550ea",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "8e020864b725798591f6",
    "url": "./static/css/main.cf107bcf.chunk.css"
  },
  {
    "revision": "eab8c368954ed29550ea",
    "url": "./static/js/2.a512d459.chunk.js"
  },
  {
    "revision": "efdf819ce7d7488cdac0bd07a7fc24a9",
    "url": "./static/js/2.a512d459.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fa962a22f3a0831b466c",
    "url": "./static/js/3.8af418a9.chunk.js"
  },
  {
    "revision": "8f6962b61567bd2d35b1563436bcf5c6",
    "url": "./static/js/3.8af418a9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d5ec5a1e0e3287f31e2c",
    "url": "./static/js/4.023a6a04.chunk.js"
  },
  {
    "revision": "8e020864b725798591f6",
    "url": "./static/js/main.77d8aa24.chunk.js"
  },
  {
    "revision": "8126ebf2d8ad5badf81d",
    "url": "./static/js/runtime-main.975994ec.js"
  },
  {
    "revision": "5b367f291ec9355e4353e7bafeab9a8f",
    "url": "./static/media/MMM.5b367f29.jpg"
  },
  {
    "revision": "58cb079c9b3ff5085eff10be894ca083",
    "url": "./static/media/Petr1.58cb079c.png"
  },
  {
    "revision": "151bf0e7bea1256d6be97921b9c99479",
    "url": "./static/media/Privatization.151bf0e7.jpg"
  },
  {
    "revision": "42e7310b105581a70aaad9608c007be5",
    "url": "./static/media/The era of palace coups.42e7310b.png"
  },
  {
    "revision": "6ad161bb06c277b94a58a2ef1ec42f29",
    "url": "./static/media/TheChechenWar.6ad161bb.jpg"
  },
  {
    "revision": "034671a1ee5523100bde865efaf3c7bf",
    "url": "./static/media/TheWhiteHouse.034671a1.jpg"
  },
  {
    "revision": "c735400ba7687cf0659ed280be4c28c0",
    "url": "./static/media/Yeltsin.c735400b.jpg"
  },
  {
    "revision": "8be729ebe4bcf4d345b22e7f39966d62",
    "url": "./static/media/Zero.8be729eb.jpg"
  },
  {
    "revision": "c735400ba7687cf0659ed280be4c28c0",
    "url": "./static/media/ageRF.c735400b.jpg"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "350153d42543c34687326a0d5c31312c",
    "url": "./static/media/img1.350153d4.jpg"
  },
  {
    "revision": "f17bd5e3d13474fe63cbfc56b098fdb5",
    "url": "./static/media/img1.f17bd5e3.png"
  },
  {
    "revision": "054fb62fea2746436d589c735ba6f31f",
    "url": "./static/media/img2.054fb62f.jpg"
  },
  {
    "revision": "a4c2df907359716d7e144576a816fe79",
    "url": "./static/media/img3.a4c2df90.jpg"
  },
  {
    "revision": "483d96951832b5288892f265fef44397",
    "url": "./static/media/img4.483d9695.jpg"
  },
  {
    "revision": "a03adca769f23ed501cbdadbce4c1005",
    "url": "./static/media/img5.a03adca7.jpg"
  },
  {
    "revision": "4498153497c70c750b39beae60a5d84d",
    "url": "./static/media/img6.44981534.jpg"
  },
  {
    "revision": "df89f5eb65c0bd2b0fa602a523fc6dc3",
    "url": "./static/media/img7.df89f5eb.jpg"
  },
  {
    "revision": "6927082b8d28377d3d72b2f5ad18d658",
    "url": "./static/media/img8.6927082b.jpg"
  },
  {
    "revision": "586c736936b38c62955d5e188df5dbf0",
    "url": "./static/media/imgLoader.586c7369.svg"
  },
  {
    "revision": "96699d6f8bba45632f3c85ac310ebdac",
    "url": "./static/media/main.96699d6f.png"
  }
]);