self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "474bb409c2c48a8ab1d589fe2da125c1",
    "url": "./index.html"
  },
  {
    "revision": "4d4d251629f707701155",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "09c079569b5229108936",
    "url": "./static/css/main.27f47257.chunk.css"
  },
  {
    "revision": "4d4d251629f707701155",
    "url": "./static/js/2.5379c100.chunk.js"
  },
  {
    "revision": "9b9de423b52b798b8fc649e7d9e276fb",
    "url": "./static/js/2.5379c100.chunk.js.LICENSE.txt"
  },
  {
    "revision": "09c079569b5229108936",
    "url": "./static/js/main.72fa1210.chunk.js"
  },
  {
    "revision": "89f12898a872a6affcf1",
    "url": "./static/js/runtime-main.615dcbd1.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "586c736936b38c62955d5e188df5dbf0",
    "url": "./static/media/imgLoader.586c7369.svg"
  }
]);