self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9fe7653545abe22b9a76816a19d26b3b",
    "url": "./index.html"
  },
  {
    "revision": "de7d41d331ea226c374b",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "f5ea9f7f7341bbc8668f",
    "url": "./static/css/main.cd15ab81.chunk.css"
  },
  {
    "revision": "de7d41d331ea226c374b",
    "url": "./static/js/2.e91b01a3.chunk.js"
  },
  {
    "revision": "21eac3191d7158f787afabb4233ee5b8",
    "url": "./static/js/2.e91b01a3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "21b9de10b34f0e4a033a",
    "url": "./static/js/3.4a879dd2.chunk.js"
  },
  {
    "revision": "8f6962b61567bd2d35b1563436bcf5c6",
    "url": "./static/js/3.4a879dd2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c942ac1561732c02f451",
    "url": "./static/js/4.b6735c52.chunk.js"
  },
  {
    "revision": "f5ea9f7f7341bbc8668f",
    "url": "./static/js/main.90581c6b.chunk.js"
  },
  {
    "revision": "14ddf069336e18260e04",
    "url": "./static/js/runtime-main.9402b45a.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "4393be32df4cde10e2ddf3fe71704e9a",
    "url": "./static/media/imgLoader.4393be32.svg"
  }
]);