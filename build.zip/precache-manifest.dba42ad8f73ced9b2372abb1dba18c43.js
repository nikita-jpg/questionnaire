self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4225610393a28bd8bbe46f64757e4553",
    "url": "./index.html"
  },
  {
    "revision": "53d624199b33ebe9e714",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "b568848bfb3c75b5ecc7",
    "url": "./static/css/main.780adbf6.chunk.css"
  },
  {
    "revision": "53d624199b33ebe9e714",
    "url": "./static/js/2.a18f6a53.chunk.js"
  },
  {
    "revision": "9e49e16072d1730b11e0472abe9dcdf1",
    "url": "./static/js/2.a18f6a53.chunk.js.LICENSE.txt"
  },
  {
    "revision": "f0c4b75290350de1f064",
    "url": "./static/js/3.439d4b02.chunk.js"
  },
  {
    "revision": "8f6962b61567bd2d35b1563436bcf5c6",
    "url": "./static/js/3.439d4b02.chunk.js.LICENSE.txt"
  },
  {
    "revision": "1f9f69b85217b25b910f",
    "url": "./static/js/4.7413975f.chunk.js"
  },
  {
    "revision": "b568848bfb3c75b5ecc7",
    "url": "./static/js/main.e9cc22ba.chunk.js"
  },
  {
    "revision": "a9a6ece306dfdd2e6d78",
    "url": "./static/js/runtime-main.88b12fd2.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "586c736936b38c62955d5e188df5dbf0",
    "url": "./static/media/imgLoader.586c7369.svg"
  }
]);