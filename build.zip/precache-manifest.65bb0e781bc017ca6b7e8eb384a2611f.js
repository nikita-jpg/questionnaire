self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5e0a0e798991698d1cb7b7b52f88665b",
    "url": "./index.html"
  },
  {
    "revision": "4fe5efdec024a9a9ce5a",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "870683fa5f5dbfbb747d",
    "url": "./static/css/main.c4c543f3.chunk.css"
  },
  {
    "revision": "4fe5efdec024a9a9ce5a",
    "url": "./static/js/2.5010c649.chunk.js"
  },
  {
    "revision": "9b9de423b52b798b8fc649e7d9e276fb",
    "url": "./static/js/2.5010c649.chunk.js.LICENSE.txt"
  },
  {
    "revision": "941795c2ebc9357a9ee2",
    "url": "./static/js/3.bff7238a.chunk.js"
  },
  {
    "revision": "8f6962b61567bd2d35b1563436bcf5c6",
    "url": "./static/js/3.bff7238a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "5ee667a8a3793968cf99",
    "url": "./static/js/4.4cff8f60.chunk.js"
  },
  {
    "revision": "870683fa5f5dbfbb747d",
    "url": "./static/js/main.883d7086.chunk.js"
  },
  {
    "revision": "f55d12ba603eaf3abd16",
    "url": "./static/js/runtime-main.2810d573.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "586c736936b38c62955d5e188df5dbf0",
    "url": "./static/media/imgLoader.586c7369.svg"
  }
]);