self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "1294ea7eeb48c3abe1cda44b28d2163c",
    "url": "./index.html"
  },
  {
    "revision": "dbc79e105f9769f79e1d",
    "url": "./static/css/2.ecd5caf4.chunk.css"
  },
  {
    "revision": "7002e38c622444e7269b",
    "url": "./static/css/main.03a609df.chunk.css"
  },
  {
    "revision": "dbc79e105f9769f79e1d",
    "url": "./static/js/2.ead8839e.chunk.js"
  },
  {
    "revision": "9b9de423b52b798b8fc649e7d9e276fb",
    "url": "./static/js/2.ead8839e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fe07c12ff4be570cd2af",
    "url": "./static/js/3.396d240c.chunk.js"
  },
  {
    "revision": "8f6962b61567bd2d35b1563436bcf5c6",
    "url": "./static/js/3.396d240c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a8ff187340f59c8a224c",
    "url": "./static/js/4.7170527a.chunk.js"
  },
  {
    "revision": "7002e38c622444e7269b",
    "url": "./static/js/main.67b6cc3c.chunk.js"
  },
  {
    "revision": "5d4206b7ec1448c8f4cf",
    "url": "./static/js/runtime-main.e63b0581.js"
  },
  {
    "revision": "0f81b4590747f516b959e25564c45694",
    "url": "./static/media/arrow.0f81b459.svg"
  },
  {
    "revision": "da748c821aa297254ad24f9544e31972",
    "url": "./static/media/book.da748c82.svg"
  },
  {
    "revision": "586c736936b38c62955d5e188df5dbf0",
    "url": "./static/media/imgLoader.586c7369.svg"
  }
]);